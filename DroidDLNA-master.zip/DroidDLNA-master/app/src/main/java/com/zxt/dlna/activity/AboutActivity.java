package com.zxt.dlna.activity;

import com.zxt.dlna.R;
import android.app.Activity;
import android.os.Bundle;

public class AboutActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
	}

}
